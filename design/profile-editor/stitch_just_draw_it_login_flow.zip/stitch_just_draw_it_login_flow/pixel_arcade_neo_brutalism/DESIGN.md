---
name: Pixel Arcade Neo-Brutalism
colors:
  surface: '#fbf8ff'
  surface-dim: '#dbd9e1'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2fb'
  surface-container: '#efecf5'
  surface-container-high: '#eae7ef'
  surface-container-highest: '#e4e1ea'
  on-surface: '#1b1b21'
  on-surface-variant: '#3d4a3e'
  inverse-surface: '#303036'
  inverse-on-surface: '#f2eff8'
  outline: '#6c7b6d'
  outline-variant: '#bbcbbb'
  surface-tint: '#006d37'
  primary: '#006d37'
  on-primary: '#ffffff'
  primary-container: '#2ecc71'
  on-primary-container: '#005027'
  inverse-primary: '#4ae183'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed023'
  on-secondary-container: '#6f5900'
  tertiary: '#5647d5'
  on-tertiary: '#ffffff'
  tertiary-container: '#b0a9ff'
  on-tertiary-container: '#3b26bb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6bfe9c'
  primary-fixed-dim: '#4ae183'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#ffe084'
  secondary-fixed-dim: '#eec209'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#e4dfff'
  tertiary-fixed-dim: '#c5c0ff'
  on-tertiary-fixed: '#140067'
  on-tertiary-fixed-variant: '#3d29bd'
  background: '#fbf8ff'
  on-background: '#1b1b21'
  surface-variant: '#e4e1ea'
typography:
  headline-xl:
    fontFamily: Rubik
    fontSize: 40px
    fontWeight: '900'
    lineHeight: 48px
    letterSpacing: 0.05em
  headline-lg:
    fontFamily: Rubik
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
  headline-sm:
    fontFamily: Rubik
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  title-md:
    fontFamily: Prompt
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 26px
  body-lg:
    fontFamily: Prompt
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Prompt
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Prompt
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 20px
  label-md:
    fontFamily: Prompt
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Prompt
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system defines an energetic, nostalgic, and hyper-playful multiplayer social experience tailored for Thai web gaming. It merges **8-bit / 16-bit Pixel Arcade** nostalgia with the sharp tactile impact of **Neo-Brutalism**. 

The brand exudes accessible chaos, warm camaraderie, and spontaneous creativity. Bold 3px–4px black strokes, chunky off-white canvas surfaces, hard directional drop shadows (isometric depth), and pixelated animal mascots evoke the joy of classic handheld consoles while maintaining modern browser ergonomics. The interface encourages lively interactions through tactile button presses, loud celebratory badges, and legible bilingual (Thai/English) typography.

## Colors
The system is built upon a saturated, high-contrast palette:
- **Canvas Base (`#5E50DE` / `#6C5CE7`):** Vivid arcade purple serving as the digital playground. Paired with a subtle repeating white dot grid (`rgba(255, 255, 255, 0.25)` at 24px intervals) to emphasize the retro game mat environment.
- **Surface Cards (`#FFFFFF` / `#F9FAFB`):** High-brightness card surfaces that cleanly contrast with the purple backdrop.
- **Primary Action (`#2ECC71` / `#3ED57E`):** Arcade green used for primary progression, "Create Room", "Ready", and start actions.
- **Secondary Accent (`#F1C40F` / `#FFD13B`):** Golden game coin yellow for active segmented toggles, star milestones, and room code badges.
- **Destructive & Urgent (`#FF5252` / `#E74C3C`):** Arcade red for "Exit Room", ribbons, countdown timers, and warning states.
- **Key Neutral (`#1E1E24` to `#000000`):** Ink-black used for all structural 3px/4px border strokes, deep hard drop shadows, and high-legibility text.

## Typography
Typography bridges the retro arcade feel with Thai script legibility:
- **Display & Key Game Titles:** Rendered using **Rubik** (or arcade-style pixel fonts like Press Start 2P / Jersey 15 where font fallback permits) with bold weights (`800`–`900`), high uppercase impact, and black outline treatments.
- **Thai Body, UI Controls, & In-Game Chat:** Driven by **Prompt**, an expressive geometric sans-serif that harmonizes with pixelated aesthetics while delivering pristine legibility on curved Thai loops and tonal markers.
- **Numbers & Scores:** Emphasize bold tabular numerals inside badges and pills to keep countdowns and point counts locked in place without jitter.

## Layout & Spacing
The layout model employs a responsive card-docking philosophy centered on an arcade cabinet viewport:
- **Canvas Container:** Fixed maximum width of 1200px on desktop, horizontally centered with `margin: 1.5rem` minimum safe space.
- **Card Grids:** Main gameplay setup cards use a split 2-column or 3-column asymmetric layout (e.g., Room Settings vs. Player Lobby & Chat). Gaps adhere firmly to `1rem` (`space-md`) or `1.25rem` (`gutter`).
- **Footer Edge:** Decorative pixel art elements (e.g., the green pixel grass strip) pin firmly to the bottom viewport border with zero margin.
- **Responsive Adaptations:** On screens `< 768px`, asymmetric split panels collapse into a single stacked column with sticky action bars at the bottom.

## Elevation & Depth
Elevation is rendered strictly through **Neo-Brutalist Hard Offset Shadows** rather than blurred ambient blurs:
- **Base Level (Canvas):** No shadow; rich purple with dot-matrix pattern.
- **Surface Level (Main Cards):** `3px solid #1E1E24` border with a crisp offset shadow: `6px 6px 0px #000000`.
- **Raised Controls (Buttons & Modals):** `3px solid #1E1E24` border with `4px 4px 0px #000000` offset shadow.
- **Pressed / Active State:** When clicking or selecting interactive pills, the offset translates (`transform: translate(2px, 2px)`) while reducing shadow size to `1px 1px 0px #000000` or `0px 0px 0px #000000`, producing an instant mechanical "click" sensation.
- **Dividers & Insets:** Subtle dashed strokes (`2px dashed #1E1E24`) for chat and player list demarcations.

## Shapes
A roundedness level of `2` provides smooth squircle corners (`16px` to `24px`) that balance the harsh neo-brutalist black strokes:
- **Main Cards & Panels:** `20px` to `24px` radius.
- **Buttons & Interactive Badges:** `14px` to `16px` radius for block buttons; full circular pill (`9999px`) for quick-switch tags, status chips, and sound toggles.
- **Avatars & Pixel Mascot Frames:** Rounded squircles (`14px` radius) surrounding sharp 8-bit sprite portraits.

## Components

### Buttons
- **Primary CTA ("Start Game", "Create Room"):** Saturated arcade green background (`#2ECC71`), 3px solid `#1E1E24` border, 4px hard black shadow, uppercase text with pixel star icon. Hover lifts slightly; `:active` translates `+2px, +2px` with depressed shadow.
- **Secondary / Action ("Join Room", "Leave Room"):** Vivid blue (`#3498DB`) or crimson red (`#E74C3C`) background, same 3px border and shadow mechanics.
- **Icon / Utility Buttons:** Squircle or circular white buttons (`#FFFFFF`) with 3px stroke housing retro icons (sound, music, back arrow).

### Segmented Controls & Multi-Select Pills
- Horizontal clusters of options (e.g., "Round Count: 1, 2, 3, 4, 5" or "Draw Time: 30, 45, 60, 90").
- Default state: White surface, 2px black border, no shadow.
- Selected state: Bright yellow fill (`#F1C40F`), 3px black border, immediate visual prominence.

### Input Fields
- White background (`#FFFFFF`), `3px solid #1E1E24` border, `12px` roundedness.
- Embedded pixel dice or randomize icon button nestled inside the input trailing edge for name rerolling.
- Focus state: Retains hard 3px black stroke accompanied by a subtle `#5E50DE` inner glow or double outline.

### Cards & Group Panels
- Main containers feature pure white backgrounds (`#FFFFFF`), 3px solid black borders, and heavy `6px 6px 0px #000000` depth.
- Header bars support ribbon tags (e.g., red polygon ribbon with white retro text) pinned over card top edges.

### Mascots & Pixel Decor
- Pixel animal avatars (Panda, Fox, Frog, Robot, Parrot) housed inside framed badges with customizable colored borders.
- Floating sparkle glyphs (`✦`) and decorative pixel grass baseline running along the footer of the screen.